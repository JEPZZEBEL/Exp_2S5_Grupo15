import java.util.Scanner;

public class TeatroMoro {
    // Variables estáticas para contabilizar estadísticas globales
    static int totalIngresos = 0;
    static int entradasVendidas = 0;
    static int entradasDisponibles = 100; // Se inicializa con el número de entradas disponibles

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int opcion;
            
            do {
                mostrarMenu();
                opcion = scanner.nextInt();
                
                switch (opcion) {
                    case 1 -> ventaEntradas(scanner);
                    case 2 -> mostrarPromociones();
                    case 3 -> System.out.println("Gracias por comprar en Teatro Moro.");
                    default -> System.out.println("Opcion invalida. Por favor, seleccione una opcion valida.");
                }
            } while (opcion != 3);
        }
    }

    public static void mostrarMenu() {
        System.out.println("=== MENU ===");
        System.out.println("1. Venta de entradas");
        System.out.println("2. Promociones");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opcion: ");
    }

    public static void ventaEntradas(Scanner scanner) {
        // Variables locales para almacenar temporalmente datos
        String tipoEntrada;
        int descuento = 0;

        // Solicitar ubicación de entrada
        System.out.print("Ingrese la ubicacion de la entrada (VIP, Platea, General): ");
        tipoEntrada = scanner.next();

        // Verificar descuentos
        System.out.print(" Es estudiante? (si/no): ");
        String respuestaEstudiante = scanner.next();
        if (respuestaEstudiante.equalsIgnoreCase("si")) {
            descuento = 10;
        } else {
            System.out.print(" Es de la tercera edad? (si/no): ");
            String respuestaTerceraEdad = scanner.next();
            if (respuestaTerceraEdad.equalsIgnoreCase("S")) {
                descuento = 15;
            } else {
                System.out.print(" Es cliente del Banco de Chile? (si/no): ");
                String respuestaBancoChile = scanner.next();
                if (respuestaBancoChile.equalsIgnoreCase("S")) {
                    descuento = 20;
                }
            }
        }

        // Calcular precio final
        int precioBase = calcularPrecioBase(tipoEntrada);
        int precioFinal = precioBase - (precioBase * descuento / 100);

        // Mostrar precio final
        System.out.println("El precio final de la entrada es: $" + precioFinal);

        // Almacenar la entrada vendida
        totalIngresos += precioFinal;
        entradasVendidas++;
        entradasDisponibles--;

        // Mostrar información sobre la venta
        System.out.println("Entrada vendida. Total de ingresos: $" + totalIngresos +
                ", Entradas disponibles: " + entradasDisponibles);
    }

    public static int calcularPrecioBase(String tipoEntrada) {
        return switch (tipoEntrada.toLowerCase()) {
            case "vip" -> 200000;
            case "platea" -> 150000;
            case "general" -> 80000;
            default -> 0;
        };
    }

    public static void mostrarPromociones() {
        System.out.println("Promociones:");
        System.out.println("- Descuento del 10% para estudiantes.");
        System.out.println("- Descuento del 15% para personas de la tercera edad.");
        System.out.println("- Descuentos especiales por compra de múltiples entradas.");
        System.out.println("- Descuento del 20% para clientes del Banco de Chile.");
    }
}
